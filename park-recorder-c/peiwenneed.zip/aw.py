# -*- coding: utf-8 -*-
from testtool import tool as tool
import math as s215ccd015e594d6cbf2831342c7ef0eb_math
import re as s215ccd015e594d6cbf2831342c7ef0eb_re
import unittest as s215ccd015e594d6cbf2831342c7ef0eb_unittest

class s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw:
    _ctb_direct_profile = 'direct_calls_v1'
    _lc_omitted = object()
    _lc_bindings = {}
    _lc_lifetimes = {}

    @classmethod
    def clear_bindings(cls):
        cls._lc_bindings = {}
        cls._lc_lifetimes = {}

    @classmethod
    def binding(cls, name, owners=()):
        return [value for key, values in cls._lc_bindings.items() if key[0] == name and (not owners or key[1] == tuple((str(v) for v in owners))) for n, value in enumerate(values) if cls._lc_lifetimes.get((key, n), True)]

    @staticmethod
    def _lc_require(condition, message):
        s215ccd015e594d6cbf2831342c7ef0eb_unittest.TestCase().assertTrue(condition, message)

    @staticmethod
    def _lc_atom(value, revision=1, depth=0):
        if isinstance(value, tuple):
            value = {'tuple': list(value)}
        if isinstance(value, dict) and set(value) == {'tuple'} and isinstance(value['tuple'], list) and value['tuple']:
            return '(' + ','.join((s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_atom(v, revision, depth + 1) for v in value['tuple'])) + ')'
        if isinstance(value, list):
            return '[' + ','.join((s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_atom(v, revision, depth + 1) for v in value)) + ']'
        if type(value) in (int, float):
            s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(s215ccd015e594d6cbf2831342c7ef0eb_math.isfinite(value), 'Nonfinite command argument')
            return str(value)
        forbidden = '[,(){}\\x00-\\x1f\\x7f"\\x27\\\\]|[^\\S ]' if revision == 2 and depth == 0 else '[,()\\[\\]{}\\x00-\\x1f\\x7f"\\x27\\\\]|[^\\S ]'
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(value, str) and (not s215ccd015e594d6cbf2831342c7ef0eb_re.search(forbidden, value)), 'Invalid literal argument: %r' % (value,))
        return value

    @staticmethod
    def _lc_wire_atom(value, parameter, depth=0):
        kind = parameter.get('type', 'scalar')
        container = kind in ('list', 'array', 'tuple_list', 'tuple') or parameter.get('list') is True
        if isinstance(value, tuple):
            value = {'tuple': list(value)}
        if isinstance(value, list):
            s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(container, 'structure_error: expected scalar at ' + str(parameter.get('name', 'item')))
            item = parameter.get('items') or parameter.get('item_type') or parameter.get('element_type') or dict(type='scalar')
            if isinstance(item, str):
                item = dict(type=item)
            if parameter.get('tuple_arity'):
                item = dict(type='tuple', tuple_arity=parameter['tuple_arity'])
            return '[' + ','.join((s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_atom(v, item, depth + 1) for v in value)) + ']'
        if isinstance(value, dict) and set(value) == {'tuple'}:
            s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(kind in ('tuple', 'scalar'), 'codec_capability_gap: tuple structure is not declared')
            values = value['tuple']
            s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(values, list) and bool(values) and (not parameter.get('tuple_arity') or len(values) == parameter['tuple_arity']), 'structure_error: tuple arity differs')
            return '(' + ','.join((s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_atom(v, 2, depth + 1) for v in values)) + ')'
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(not container, 'structure_error: expected container at ' + str(parameter.get('name', 'item')))
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(type(value) in (str, int, float) and (type(value) is not float or s215ccd015e594d6cbf2831342c7ef0eb_math.isfinite(value)), 'structure_error: expected finite literal')
        return s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_atom(value, 2, depth)

    @staticmethod
    def _lc_wire_args(args, parameters, arities):
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(len(args) in arities, 'structure_error: unsupported call arity')
        return ','.join((s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_atom(v, parameters[n]) for n, v in enumerate(args)))

    @staticmethod
    def _lc_capture(raw, prefix, pattern='', mode='', field_pattern='', letter_count=None, unique_letters=False, transform='identity', extract_pattern=''):
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(raw.startswith(prefix), 'Response prefix mismatch: %r' % raw)
        value = raw[len(prefix):]
        if mode == 'status_and_extract_v2':
            found = list(s215ccd015e594d6cbf2831342c7ef0eb_re.finditer(field_pattern, value))
            s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(len(found) == 1 and found[0].re.groups == 1 and bool(found[0].group(1)), 'Dynamic field missing or ambiguous: %r' % raw)
            value = found[0].group(1)
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(not pattern or s215ccd015e594d6cbf2831342c7ef0eb_re.fullmatch(pattern, value) is not None, 'Dynamic field format mismatch: %r' % value)
        letters = ''.join((c for c in value if c.isascii() and c.isalpha()))
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(letter_count is None or len(letters) == letter_count, 'Dynamic field letter count mismatch')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(not unique_letters or len(set(letters)) == len(letters), 'Dynamic field letters must be distinct')
        if transform == 'letters':
            return letters
        if transform == 'regex':
            value = ''.join((''.join(m.groups(default='')) if m.re.groups else m.group() for m in s215ccd015e594d6cbf2831342c7ef0eb_re.finditer(extract_pattern, value)))
            s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(bool(value), 'Custom extraction pattern returned no value')
        return value

    @classmethod
    def init(cls):
        args = []
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        cls.clear_bindings()
        raw = tool.send_cmd('init(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [], [0]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def time_pass(cls, step_type, value):
        args = [step_type, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('time_pass(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'step_type', 'type': 'enum'}, {'name': 'value', 'type': 'integer'}], [2]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @staticmethod
    def extract_register_account_id(response):
        return s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_capture(response.rstrip('\r\n'), prefix='E000:', mode='status_and_extract_v2', field_pattern='(CID[0-9]{8})', transform='identity')

    @staticmethod
    def extract_register_account_id_1(response):
        return s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_capture(response.rstrip('\r\n'), prefix='E000:', mode='status_and_extract_v2', field_pattern=',\\s*([0-9]{6})', transform='identity')

    @classmethod
    def register_account(cls, phone, password):
        args = [phone, password]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('register_account(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'phone', 'type': 'identity'}, {'name': 'password', 'type': 'string'}], [2]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        if raw.rstrip('\r\n').startswith('E000:'):
            value = cls.extract_register_account_id(raw)
            key = ('map_register_account', tuple((str(v) for v in [args[0]])))
            values = cls._lc_bindings.setdefault(key, [])
            values.append(value)
        if raw.rstrip('\r\n').startswith('E000:'):
            value = cls.extract_register_account_id_1(raw)
            key = ('map_register_verify_code', tuple((str(v) for v in [args[0]])))
            values = cls._lc_bindings.setdefault(key, [])
            values.append(value)
        return raw

    @classmethod
    def unregister_account(cls, member_id, password):
        args = [member_id, password]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('unregister_account(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'password', 'type': 'string'}], [2]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def bind_plate_id(cls, member_id, plate_id):
        args = [member_id, plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('bind_plate_id(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'plate_id', 'type': 'identity'}], [2]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def unbind_plate_id(cls, member_id, plate_id):
        args = [member_id, plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('unbind_plate_id(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'plate_id', 'type': 'identity'}], [2]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @staticmethod
    def extract_car_entry_id(response):
        return s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_capture(response.rstrip('\r\n'), prefix='E000:', mode='status_and_extract_v2', field_pattern='(p[0-9]{16})', transform='identity')

    @classmethod
    def car_entry(cls, plate_id, gate_id):
        args = [plate_id, gate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('car_entry(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}, {'name': 'gate_id', 'type': 'enum'}], [2]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        if raw.rstrip('\r\n').startswith('E000:'):
            value = cls.extract_car_entry_id(raw)
            key = ('map_car_entry', tuple((str(v) for v in [args[0]])))
            values = cls._lc_bindings.setdefault(key, [])
            values.append(value)
        return raw

    @classmethod
    def occupy_park(cls, session_id, space_id):
        args = [session_id, space_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('occupy_park(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}, {'name': 'space_id', 'type': 'enum'}], [2]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def release_park(cls, session_id):
        args = [session_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('release_park(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}], [1]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def car_exit(cls, session_id, gate_id):
        args = [session_id, gate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('car_exit(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}, {'name': 'gate_id', 'type': 'enum'}], [2]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def change_gate(cls, gate_id, io_dir):
        args = [gate_id, io_dir]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('change_gate(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'gate_id', 'type': 'enum'}, {'name': 'io_dir', 'type': 'enum'}], [2]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_account(cls, member_id):
        args = [member_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_account(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}], [1]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_bindcar_info(cls, member_id):
        args = [member_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_bindcar_info(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}], [1]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_gate_status(cls, gate_id):
        args = [gate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_gate_status(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'gate_id', 'type': 'enum'}], [1]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_car_status(cls, plate_id, session_id, status):
        args = [plate_id, session_id, status]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_car_status(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}, {'name': 'session_id', 'type': 'string'}, {'name': 'status', 'type': 'enum'}], [3]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def add_blacklist(cls, plate_id):
        args = [plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('add_blacklist(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}], [1]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def del_blacklist(cls, plate_id):
        args = [plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('del_blacklist(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}], [1]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def recharge_account(cls, member_id, value):
        args = [member_id, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('recharge_account(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'value', 'type': 'integer'}], [2]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def transfer_account(cls, member_id1, member_id2, value):
        args = [member_id1, member_id2, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('transfer_account(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'member_id1', 'type': 'string'}, {'name': 'member_id2', 'type': 'string'}, {'name': 'value', 'type': 'integer'}], [3]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def purchase_moncard(cls, member_id, plate_id):
        args = [member_id, plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('purchase_moncard(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'plate_id', 'type': 'identity'}], [2]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def transfer_moncard(cls, plate_id1, plate_id2, value):
        args = [plate_id1, plate_id2, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('transfer_moncard(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'plate_id1', 'type': 'identity'}, {'name': 'plate_id2', 'type': 'identity'}, {'name': 'value', 'type': 'integer'}], [3]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def pay_parkcost(cls, session_id, pay_type, pay_value):
        args = [session_id, pay_type, pay_value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('pay_parkcost(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}, {'name': 'pay_type', 'type': 'enum'}, {'name': 'pay_value', 'type': 'string'}], [3]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_account_asset(cls, member_id):
        args = [member_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_account_asset(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}], [1]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_revenue(cls, type, revenue_type, value):
        args = [type, revenue_type, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_revenue(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'type', 'type': 'enum'}, {'name': 'revenue_type', 'type': 'enum'}, {'name': 'value', 'type': 'string'}], [3]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def activate_account(cls, member_id, verify_code):
        args = [member_id, verify_code]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('activate_account(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'verify_code', 'type': 'string'}], [2]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_occupied_spaces(cls, used_num, used_park_list):
        args = [used_num, used_park_list]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_occupied_spaces(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'used_num', 'type': 'string'}, {'name': 'used_park_list', 'type': 'string'}], [2]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_park_statistics(cls, small_stats, medium_stats, large_stats):
        args = [small_stats, medium_stats, large_stats]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_park_statistics(' + s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_wire_args(args, [{'name': 'small_stats', 'type': 'string'}, {'name': 'medium_stats', 'type': 'string'}, {'name': 'large_stats', 'type': 'string'}], [3]) + ')')
        s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw
s215ccd015e594d6cbf2831342c7ef0eb_Aw = s215ccd015e594d6cbf2831342c7ef0eb_ParkingB03Aw
s215ccd015e594d6cbf2831342c7ef0eb_init_service = s215ccd015e594d6cbf2831342c7ef0eb_Aw.init
from testtool import tool as tool
import re as se427eda6f778479282b7b5bb7c2a1d81_re

def se427eda6f778479282b7b5bb7c2a1d81_cjl_init_service():
    return tool.send_cmd('init()')

def se427eda6f778479282b7b5bb7c2a1d81_cjl_run_turns(times=1):
    for i in range(times):
        tool.send_cmd('init()')
se427eda6f778479282b7b5bb7c2a1d81_rS = 'E000:Success'
se427eda6f778479282b7b5bb7c2a1d81_rF = 'E001:Fail'
se427eda6f778479282b7b5bb7c2a1d81_rL = 'E002:Locked'
se427eda6f778479282b7b5bb7c2a1d81_SP = {'E001:Fail': 'rF', 'E000:Success': 'rS', 'E002:Locked': 'rL'}

class se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil:
    """
    通用的命令下发AW，提供normal、ret_id两种模式，供cjl_Aw方法使用
    """
    JUDGEMENT_FLAG = True
    CALCBASE = 10
    TIMEFORMAT = '%Y-%m-%d %H:%M:%S'
    RECORD_FAIL_FLAG = True
    TC_Start = []
    TC_End = []
    CASE_ID = 0

    @staticmethod
    def next_testcase(name):
        se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.CASE_ID += 1
        se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.add_context(f'    def test_{name}(self):', '        cjl_init_service()')

    @staticmethod
    def add_context(*context):
        for s in context:
            if not s.endswith('\n'):
                s += '\n'
            se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.TC_Start.append(s)

    @staticmethod
    def _add_aw_context(cmd, ret, aw_name='', *args):
        if not se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.RECORD_FAIL_FLAG and ret == se427eda6f778479282b7b5bb7c2a1d81_rF:
            return
        if ret in se427eda6f778479282b7b5bb7c2a1d81_SP:
            ret = se427eda6f778479282b7b5bb7c2a1d81_SP[ret]
        else:
            ret = f"'{ret}'"
        cmd = aw_name if aw_name else cmd

        def fmt_arg(x):
            if isinstance(x, (int, float)):
                return str(x)
            return f"'{x}'"
        args_list = [fmt_arg(x) for x in args]
        args_str = f"{','.join(args_list)}, " if args_list else ''
        context = f'        aw.{cmd}({args_str}expects={ret})'
        se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.add_context(context)

    @staticmethod
    def send_cmd(cmd, *args, **kwargs):
        full_cmd = f"{cmd}({','.join([str(x) for x in args])})"
        ret = tool.send_cmd(full_cmd).replace('\n', '')
        return ret

    @staticmethod
    def send_cmd_normal(cmd: str, *args, aw_name='', **expects):
        """
        适合入参范围明确、返回值固定的函数，全等比较
        """
        ret = se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd(cmd, *args)
        if not se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG:
            se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil._add_aw_context(cmd, ret, aw_name if aw_name else 'cjl_' + cmd, *args)
        else:
            if 'expects' not in expects or expects['expects'] == '':
                raise ValueError(f'JUDGEMENT_FLAG=True but expects not provided for: {cmd}({args})')
            expect_value = expects['expects']
            assert ret == expect_value, f'cmd={cmd}({args}), expected={expect_value!r}, actual={ret!r}'
        return ret

    @staticmethod
    def send_cmd_ret_id(cmd: str, *args, aw_name='', **expects):
        """
        适合返回值带动态ID，ID值不做全等校验、只比前5字符
        """
        ret = se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd(cmd, *args)
        if not se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG:
            se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil._add_aw_context(cmd, ret, aw_name if aw_name else 'cjl_' + cmd, *args)
        else:
            if 'expects' not in expects or expects['expects'] == '':
                raise ValueError(f'JUDGEMENT_FLAG=True but expects not provided for: {cmd}({args})')
            expect_value = expects['expects']
            if expect_value in se427eda6f778479282b7b5bb7c2a1d81_SP:
                assert ret == expect_value, f'cmd={cmd}({args}), expected={expect_value!r}, actual={ret!r}'
            else:
                assert ret[:5] == expect_value[:5], f'cmd={cmd}({args}), expected_prefix={expect_value[:5]!r}, actual_prefix={ret[:5]!r}, full_actual={ret!r}'
        return ret

class se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw:
    """智慧园区停车场系统(B版本) AW封装

    在A版本基础上新增：
      - 黑名单：add_blacklist / del_blacklist
      - 账户充值：recharge_account
      - 余额转让：transfer_account
      - 月卡：purchase_moncard / transfer_moncard
      - 账单结算：pay_parkcost
      - 查询资产：query_account_asset
      - 检查接口：check_occupied_spaces / check_park_statistics / check_revenue
    变更：
      - occupy_park 新增 space_id 参数
    """
    map_member = {}
    map_code = {}
    map_session = {}

    @staticmethod
    def _extract_field(text, prefix, suffix=''):
        """从text中提取prefix和suffix之间的内容"""
        start = text.find(prefix)
        if start == -1:
            return None
        start += len(prefix)
        if suffix:
            end = text.find(suffix, start)
            if end == -1:
                return text[start:]
            return text[start:end]
        return text[start:]

    @staticmethod
    def _bind(table, recorded, actual, what):
        """录制值到实际值的映射：已出现的录制值必须对应同一实际值，新录制值不能对应已用过的实际值"""
        if recorded in table:
            assert table[recorded] == actual, f'{what}: recorded={recorded!r} mapped={table[recorded]!r}, actual={actual!r}'
        else:
            assert actual not in table.values(), f'{what}: recorded={recorded!r} is new but actual={actual!r} already used'
            table[recorded] = actual

    @staticmethod
    def init(expects=se427eda6f778479282b7b5bb7c2a1d81_rS):
        maps = [i for i in se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.__dict__ if i[0:4] == 'map_']
        for i in maps:
            setattr(se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw, i, {})
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('init', expects=expects)

    @staticmethod
    def cjl_time_pass(step_type, value, expects=''):
        args = [step_type, value]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('time_pass', *args, expects=expects)

    @staticmethod
    def cjl_register_account(phone, password, expects=''):
        """返回 E000:CIDxxxx,6位验证码，拆分并映射 member_id 和 code"""
        args = [phone, password]
        ret = se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_ret_id('register_account', *args, expects=expects)
        m = se427eda6f778479282b7b5bb7c2a1d81_re.match('E000:(CID\\d{8}),(\\d{6})', ret)
        if not m:
            return ret
        cid, code = (m.group(1), m.group(2))
        if se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG and expects.startswith('E000:'):
            em = se427eda6f778479282b7b5bb7c2a1d81_re.match('E000:(CID\\d{8}),(\\d{6})', expects)
            if em:
                se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw._bind(se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member, em.group(1), cid, 'register_account member_id')
                se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_code[em.group(1)] = (em.group(2), code)
        return (cid, code)

    @staticmethod
    def cjl_activate_account(member_id, verify_code, expects=''):
        """验证码按录制的 member_id 映射：传入值等于该账户录制时的验证码才替换为实际验证码"""
        if se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG:
            recorded = se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_code.get(member_id)
            if recorded and verify_code == recorded[0]:
                verify_code = recorded[1]
            if member_id in se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member:
                member_id = se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member[member_id]
        args = [member_id, verify_code]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('activate_account', *args, expects=expects)

    @staticmethod
    def cjl_unregister_account(member_id, password, expects=''):
        if se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG and member_id in se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member:
            member_id = se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member[member_id]
        args = [member_id, password]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('unregister_account', *args, expects=expects)

    @staticmethod
    def cjl_query_account(member_id, expects=''):
        if se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG and member_id in se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member:
            member_id = se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member[member_id]
        args = [member_id]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('query_account', *args, expects=expects)

    @staticmethod
    def cjl_bind_plate_id(member_id, plate_id, expects=''):
        if se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG and member_id in se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member:
            member_id = se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member[member_id]
        args = [member_id, plate_id]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('bind_plate_id', *args, expects=expects)

    @staticmethod
    def cjl_unbind_plate_id(member_id, plate_id, expects=''):
        if se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG and member_id in se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member:
            member_id = se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member[member_id]
        args = [member_id, plate_id]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('unbind_plate_id', *args, expects=expects)

    @staticmethod
    def cjl_query_bindcar_info(member_id, expects=''):
        if se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG and member_id in se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member:
            member_id = se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member[member_id]
        args = [member_id]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('query_bindcar_info', *args, expects=expects)

    @staticmethod
    def cjl_car_entry(plate_id, gate_id, expects=''):
        """返回 E000:session_id,account_id，拆分并映射 session_id"""
        args = [plate_id, gate_id]
        ret = se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_ret_id('car_entry', *args, expects=expects)
        m = se427eda6f778479282b7b5bb7c2a1d81_re.match('E000:(p\\d{16}),(CID\\d{8})', ret)
        if not m:
            return ret
        session_id, acc_id = (m.group(1), m.group(2))
        if se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG and expects.startswith('E000:'):
            em = se427eda6f778479282b7b5bb7c2a1d81_re.match('E000:(p\\d{16}),(CID\\d{8})', expects)
            if em:
                se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw._bind(se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_session, em.group(1), session_id, 'car_entry session_id')
                se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw._bind(se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member, em.group(2), acc_id, 'car_entry account_id')
        return (session_id, acc_id)

    @staticmethod
    def cjl_occupy_park(session_id, space_id=None, expects=''):
        """B版本新增 space_id 参数；A版本不传 space_id"""
        if se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG and session_id in se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_session:
            session_id = se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_session[session_id]
        args = [session_id] if space_id is None else [session_id, space_id]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('occupy_park', *args, expects=expects)

    @staticmethod
    def cjl_release_park(session_id, expects=''):
        """B版本：返回 E000:车位号（如E000:S010），车位号确定，全等比较"""
        if se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG and session_id in se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_session:
            session_id = se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_session[session_id]
        args = [session_id]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('release_park', *args, expects=expects)

    @staticmethod
    def cjl_car_exit(session_id, gate_id, expects=''):
        if se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG and session_id in se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_session:
            session_id = se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_session[session_id]
        args = [session_id, gate_id]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('car_exit', *args, expects=expects)

    @staticmethod
    def cjl_check_car_status(plate_id, session_id, status, expects=''):
        if se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG and session_id in se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_session:
            session_id = se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_session[session_id]
        args = [plate_id, session_id, status]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('check_car_status', *args, expects=expects)

    @staticmethod
    def cjl_change_gate(gate_id, io_dir, expects=''):
        args = [gate_id, io_dir]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('change_gate', *args, expects=expects)

    @staticmethod
    def cjl_query_gate_status(gate_id, expects=''):
        args = [gate_id]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('query_gate_status', *args, expects=expects)

    @staticmethod
    def cjl_add_blacklist(plate_id, expects=''):
        args = [plate_id]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('add_blacklist', *args, expects=expects)

    @staticmethod
    def cjl_del_blacklist(plate_id, expects=''):
        args = [plate_id]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('del_blacklist', *args, expects=expects)

    @staticmethod
    def cjl_recharge_account(member_id, value, expects=''):
        if se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG and member_id in se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member:
            member_id = se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member[member_id]
        args = [member_id, value]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('recharge_account', *args, expects=expects)

    @staticmethod
    def cjl_transfer_account(member_id1, member_id2, value, expects=''):
        if se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG and member_id1 in se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member:
            member_id1 = se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member[member_id1]
        if se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG and member_id2 in se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member:
            member_id2 = se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member[member_id2]
        args = [member_id1, member_id2, value]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('transfer_account', *args, expects=expects)

    @staticmethod
    def cjl_purchase_moncard(member_id, plate_id, expects=''):
        if se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG and member_id in se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member:
            member_id = se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member[member_id]
        args = [member_id, plate_id]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('purchase_moncard', *args, expects=expects)

    @staticmethod
    def cjl_transfer_moncard(plate_id1, plate_id2, value, expects=''):
        args = [plate_id1, plate_id2, value]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('transfer_moncard', *args, expects=expects)

    @staticmethod
    def cjl_pay_parkcost(session_id, pay_type, pay_value, expects=''):
        if se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG and session_id in se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_session:
            session_id = se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_session[session_id]
        args = [session_id, pay_type, pay_value]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('pay_parkcost', *args, expects=expects)

    @staticmethod
    def cjl_query_account_asset(member_id, expects=''):
        if se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.JUDGEMENT_FLAG and member_id in se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member:
            member_id = se427eda6f778479282b7b5bb7c2a1d81_cjl_Aw.map_member[member_id]
        args = [member_id]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('query_account_asset', *args, expects=expects)

    @staticmethod
    def cjl_check_occupied_spaces(used_num, used_park_list, expects=''):
        args = [used_num, used_park_list]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('check_occupied_spaces', *args, expects=expects)

    @staticmethod
    def cjl_check_park_statistics(small_stats, medium_stats, large_stats, expects=''):
        args = [small_stats, medium_stats, large_stats]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('check_park_statistics', *args, expects=expects)

    @staticmethod
    def cjl_check_revenue(type_, revenue_type, value, expects=''):
        args = [type_, revenue_type, value]
        return se427eda6f778479282b7b5bb7c2a1d81_cjl_CommonUtil.send_cmd_normal('check_revenue', *args, expects=expects)
from testtool import tool as tool
import math as s1b32369458404c98a8cd748a641eef73_math
import re as s1b32369458404c98a8cd748a641eef73_re
import unittest as s1b32369458404c98a8cd748a641eef73_unittest

class s1b32369458404c98a8cd748a641eef73_ParkingB01Aw:
    _ctb_direct_profile = 'direct_calls_v1'
    _lc_omitted = object()
    _lc_bindings = {}
    _lc_lifetimes = {}

    @classmethod
    def clear_bindings(cls):
        cls._lc_bindings = {}
        cls._lc_lifetimes = {}

    @classmethod
    def binding(cls, name, owners=()):
        return [value for key, values in cls._lc_bindings.items() if key[0] == name and (not owners or key[1] == tuple((str(v) for v in owners))) for n, value in enumerate(values) if cls._lc_lifetimes.get((key, n), True)]

    @staticmethod
    def _lc_require(condition, message):
        s1b32369458404c98a8cd748a641eef73_unittest.TestCase().assertTrue(condition, message)

    @staticmethod
    def _lc_atom(value, revision=1, depth=0):
        if isinstance(value, tuple):
            value = {'tuple': list(value)}
        if isinstance(value, dict) and set(value) == {'tuple'} and isinstance(value['tuple'], list) and value['tuple']:
            return '(' + ','.join((s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_atom(v, revision, depth + 1) for v in value['tuple'])) + ')'
        if isinstance(value, list):
            return '[' + ','.join((s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_atom(v, revision, depth + 1) for v in value)) + ']'
        if type(value) in (int, float):
            s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(s1b32369458404c98a8cd748a641eef73_math.isfinite(value), 'Nonfinite command argument')
            return str(value)
        forbidden = '[,(){}\\x00-\\x1f\\x7f"\\x27\\\\]|[^\\S ]' if revision == 2 and depth == 0 else '[,()\\[\\]{}\\x00-\\x1f\\x7f"\\x27\\\\]|[^\\S ]'
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(value, str) and (not s1b32369458404c98a8cd748a641eef73_re.search(forbidden, value)), 'Invalid literal argument: %r' % (value,))
        return value

    @staticmethod
    def _lc_wire_atom(value, parameter, depth=0):
        kind = parameter.get('type', 'scalar')
        container = kind in ('list', 'array', 'tuple_list', 'tuple') or parameter.get('list') is True
        if isinstance(value, tuple):
            value = {'tuple': list(value)}
        if isinstance(value, list):
            s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(container, 'structure_error: expected scalar at ' + str(parameter.get('name', 'item')))
            item = parameter.get('items') or parameter.get('item_type') or parameter.get('element_type') or dict(type='scalar')
            if isinstance(item, str):
                item = dict(type=item)
            if parameter.get('tuple_arity'):
                item = dict(type='tuple', tuple_arity=parameter['tuple_arity'])
            return '[' + ','.join((s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_atom(v, item, depth + 1) for v in value)) + ']'
        if isinstance(value, dict) and set(value) == {'tuple'}:
            s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(kind in ('tuple', 'scalar'), 'codec_capability_gap: tuple structure is not declared')
            values = value['tuple']
            s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(values, list) and bool(values) and (not parameter.get('tuple_arity') or len(values) == parameter['tuple_arity']), 'structure_error: tuple arity differs')
            return '(' + ','.join((s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_atom(v, 2, depth + 1) for v in values)) + ')'
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(not container, 'structure_error: expected container at ' + str(parameter.get('name', 'item')))
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(type(value) in (str, int, float) and (type(value) is not float or s1b32369458404c98a8cd748a641eef73_math.isfinite(value)), 'structure_error: expected finite literal')
        return s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_atom(value, 2, depth)

    @staticmethod
    def _lc_wire_args(args, parameters, arities):
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(len(args) in arities, 'structure_error: unsupported call arity')
        return ','.join((s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_atom(v, parameters[n]) for n, v in enumerate(args)))

    @staticmethod
    def _lc_capture(raw, prefix, pattern='', mode='', field_pattern='', letter_count=None, unique_letters=False, transform='identity', extract_pattern=''):
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(raw.startswith(prefix), 'Response prefix mismatch: %r' % raw)
        value = raw[len(prefix):]
        if mode == 'status_and_extract_v2':
            found = list(s1b32369458404c98a8cd748a641eef73_re.finditer(field_pattern, value))
            s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(len(found) == 1 and found[0].re.groups == 1 and bool(found[0].group(1)), 'Dynamic field missing or ambiguous: %r' % raw)
            value = found[0].group(1)
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(not pattern or s1b32369458404c98a8cd748a641eef73_re.fullmatch(pattern, value) is not None, 'Dynamic field format mismatch: %r' % value)
        letters = ''.join((c for c in value if c.isascii() and c.isalpha()))
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(letter_count is None or len(letters) == letter_count, 'Dynamic field letter count mismatch')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(not unique_letters or len(set(letters)) == len(letters), 'Dynamic field letters must be distinct')
        if transform == 'letters':
            return letters
        if transform == 'regex':
            value = ''.join((''.join(m.groups(default='')) if m.re.groups else m.group() for m in s1b32369458404c98a8cd748a641eef73_re.finditer(extract_pattern, value)))
            s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(bool(value), 'Custom extraction pattern returned no value')
        return value

    @classmethod
    def init(cls):
        args = []
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        cls.clear_bindings()
        raw = tool.send_cmd('init(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [], [0]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def time_pass(cls, step_type, value):
        args = [step_type, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('time_pass(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'step_type', 'type': 'enum'}, {'name': 'value', 'type': 'integer'}], [2]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @staticmethod
    def extract_register_account_id(response):
        return s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_capture(response.rstrip('\r\n'), prefix='E000:', mode='status_and_extract_v2', field_pattern='(CID[0-9]{8})', transform='identity')

    @staticmethod
    def extract_register_account_id_1(response):
        return s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_capture(response.rstrip('\r\n'), prefix='E000:', mode='status_and_extract_v2', field_pattern=',\\s*([0-9]{6})', transform='identity')

    @classmethod
    def register_account(cls, phone, password):
        args = [phone, password]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('register_account(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'phone', 'type': 'identity'}, {'name': 'password', 'type': 'string'}], [2]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        if raw.rstrip('\r\n').startswith('E000:'):
            value = cls.extract_register_account_id(raw)
            key = ('map_register_account', tuple((str(v) for v in [args[0]])))
            values = cls._lc_bindings.setdefault(key, [])
            values.append(value)
        if raw.rstrip('\r\n').startswith('E000:'):
            value = cls.extract_register_account_id_1(raw)
            key = ('map_register_verify_code', tuple((str(v) for v in [args[0]])))
            values = cls._lc_bindings.setdefault(key, [])
            values.append(value)
        return raw

    @classmethod
    def unregister_account(cls, member_id, password):
        args = [member_id, password]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('unregister_account(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'password', 'type': 'string'}], [2]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def bind_plate_id(cls, member_id, plate_id):
        args = [member_id, plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('bind_plate_id(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'plate_id', 'type': 'identity'}], [2]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def unbind_plate_id(cls, member_id, plate_id):
        args = [member_id, plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('unbind_plate_id(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'plate_id', 'type': 'identity'}], [2]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @staticmethod
    def extract_car_entry_id(response):
        return s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_capture(response.rstrip('\r\n'), prefix='E000:', mode='status_and_extract_v2', field_pattern='(p[0-9]{16})', transform='identity')

    @classmethod
    def car_entry(cls, plate_id, gate_id):
        args = [plate_id, gate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('car_entry(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}, {'name': 'gate_id', 'type': 'enum'}], [2]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        if raw.rstrip('\r\n').startswith('E000:'):
            value = cls.extract_car_entry_id(raw)
            key = ('map_car_entry', tuple((str(v) for v in [args[0]])))
            values = cls._lc_bindings.setdefault(key, [])
            values.append(value)
        return raw

    @classmethod
    def occupy_park(cls, session_id, space_id):
        args = [session_id, space_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('occupy_park(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}, {'name': 'space_id', 'type': 'enum'}], [2]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def release_park(cls, session_id):
        args = [session_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('release_park(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}], [1]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def car_exit(cls, session_id, gate_id):
        args = [session_id, gate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('car_exit(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}, {'name': 'gate_id', 'type': 'enum'}], [2]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def change_gate(cls, gate_id, io_dir):
        args = [gate_id, io_dir]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('change_gate(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'gate_id', 'type': 'enum'}, {'name': 'io_dir', 'type': 'enum'}], [2]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_account(cls, member_id):
        args = [member_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_account(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}], [1]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_bindcar_info(cls, member_id):
        args = [member_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_bindcar_info(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}], [1]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_gate_status(cls, gate_id):
        args = [gate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_gate_status(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'gate_id', 'type': 'enum'}], [1]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_car_status(cls, plate_id, session_id, status):
        args = [plate_id, session_id, status]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_car_status(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}, {'name': 'session_id', 'type': 'string'}, {'name': 'status', 'type': 'enum'}], [3]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def add_blacklist(cls, plate_id):
        args = [plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('add_blacklist(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}], [1]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def del_blacklist(cls, plate_id):
        args = [plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('del_blacklist(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}], [1]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def recharge_account(cls, member_id, value):
        args = [member_id, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('recharge_account(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'value', 'type': 'integer'}], [2]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def transfer_account(cls, member_id1, member_id2, value):
        args = [member_id1, member_id2, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('transfer_account(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'member_id1', 'type': 'string'}, {'name': 'member_id2', 'type': 'string'}, {'name': 'value', 'type': 'integer'}], [3]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def purchase_moncard(cls, member_id, plate_id):
        args = [member_id, plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('purchase_moncard(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'plate_id', 'type': 'identity'}], [2]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def transfer_moncard(cls, plate_id1, plate_id2, value):
        args = [plate_id1, plate_id2, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('transfer_moncard(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'plate_id1', 'type': 'identity'}, {'name': 'plate_id2', 'type': 'identity'}, {'name': 'value', 'type': 'integer'}], [3]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def pay_parkcost(cls, session_id, pay_type, pay_value):
        args = [session_id, pay_type, pay_value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('pay_parkcost(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}, {'name': 'pay_type', 'type': 'enum'}, {'name': 'pay_value', 'type': 'string'}], [3]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_account_asset(cls, member_id):
        args = [member_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_account_asset(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}], [1]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_revenue(cls, type, revenue_type, value):
        args = [type, revenue_type, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_revenue(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'type', 'type': 'enum'}, {'name': 'revenue_type', 'type': 'enum'}, {'name': 'value', 'type': 'string'}], [3]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def activate_account(cls, member_id, verify_code):
        args = [member_id, verify_code]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('activate_account(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'verify_code', 'type': 'string'}], [2]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_occupied_spaces(cls, used_num, used_park_list):
        args = [used_num, used_park_list]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_occupied_spaces(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'used_num', 'type': 'string'}, {'name': 'used_park_list', 'type': 'string'}], [2]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_park_statistics(cls, small_stats, medium_stats, large_stats):
        args = [small_stats, medium_stats, large_stats]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_park_statistics(' + s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_wire_args(args, [{'name': 'small_stats', 'type': 'string'}, {'name': 'medium_stats', 'type': 'string'}, {'name': 'large_stats', 'type': 'string'}], [3]) + ')')
        s1b32369458404c98a8cd748a641eef73_ParkingB01Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw
s1b32369458404c98a8cd748a641eef73_Aw = s1b32369458404c98a8cd748a641eef73_ParkingB01Aw
s1b32369458404c98a8cd748a641eef73_init_service = s1b32369458404c98a8cd748a641eef73_Aw.init
from testtool import tool as tool
import math as s1d18e60290534f4e8ee0b1e639850ad0_math
import re as s1d18e60290534f4e8ee0b1e639850ad0_re
import unittest as s1d18e60290534f4e8ee0b1e639850ad0_unittest

class s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw:
    _ctb_direct_profile = 'direct_calls_v1'
    _lc_omitted = object()
    _lc_bindings = {}
    _lc_lifetimes = {}

    @classmethod
    def clear_bindings(cls):
        cls._lc_bindings = {}
        cls._lc_lifetimes = {}

    @classmethod
    def binding(cls, name, owners=()):
        return [value for key, values in cls._lc_bindings.items() if key[0] == name and (not owners or key[1] == tuple((str(v) for v in owners))) for n, value in enumerate(values) if cls._lc_lifetimes.get((key, n), True)]

    @staticmethod
    def _lc_require(condition, message):
        s1d18e60290534f4e8ee0b1e639850ad0_unittest.TestCase().assertTrue(condition, message)

    @staticmethod
    def _lc_atom(value, revision=1, depth=0):
        if isinstance(value, tuple):
            value = {'tuple': list(value)}
        if isinstance(value, dict) and set(value) == {'tuple'} and isinstance(value['tuple'], list) and value['tuple']:
            return '(' + ','.join((s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_atom(v, revision, depth + 1) for v in value['tuple'])) + ')'
        if isinstance(value, list):
            return '[' + ','.join((s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_atom(v, revision, depth + 1) for v in value)) + ']'
        if type(value) in (int, float):
            s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(s1d18e60290534f4e8ee0b1e639850ad0_math.isfinite(value), 'Nonfinite command argument')
            return str(value)
        forbidden = '[,(){}\\x00-\\x1f\\x7f"\\x27\\\\]|[^\\S ]' if revision == 2 and depth == 0 else '[,()\\[\\]{}\\x00-\\x1f\\x7f"\\x27\\\\]|[^\\S ]'
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(value, str) and (not s1d18e60290534f4e8ee0b1e639850ad0_re.search(forbidden, value)), 'Invalid literal argument: %r' % (value,))
        return value

    @staticmethod
    def _lc_wire_atom(value, parameter, depth=0):
        kind = parameter.get('type', 'scalar')
        container = kind in ('list', 'array', 'tuple_list', 'tuple') or parameter.get('list') is True
        if isinstance(value, tuple):
            value = {'tuple': list(value)}
        if isinstance(value, list):
            s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(container, 'structure_error: expected scalar at ' + str(parameter.get('name', 'item')))
            item = parameter.get('items') or parameter.get('item_type') or parameter.get('element_type') or dict(type='scalar')
            if isinstance(item, str):
                item = dict(type=item)
            if parameter.get('tuple_arity'):
                item = dict(type='tuple', tuple_arity=parameter['tuple_arity'])
            return '[' + ','.join((s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_atom(v, item, depth + 1) for v in value)) + ']'
        if isinstance(value, dict) and set(value) == {'tuple'}:
            s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(kind in ('tuple', 'scalar'), 'codec_capability_gap: tuple structure is not declared')
            values = value['tuple']
            s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(values, list) and bool(values) and (not parameter.get('tuple_arity') or len(values) == parameter['tuple_arity']), 'structure_error: tuple arity differs')
            return '(' + ','.join((s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_atom(v, 2, depth + 1) for v in values)) + ')'
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(not container, 'structure_error: expected container at ' + str(parameter.get('name', 'item')))
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(type(value) in (str, int, float) and (type(value) is not float or s1d18e60290534f4e8ee0b1e639850ad0_math.isfinite(value)), 'structure_error: expected finite literal')
        return s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_atom(value, 2, depth)

    @staticmethod
    def _lc_wire_args(args, parameters, arities):
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(len(args) in arities, 'structure_error: unsupported call arity')
        return ','.join((s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_atom(v, parameters[n]) for n, v in enumerate(args)))

    @staticmethod
    def _lc_capture(raw, prefix, pattern='', mode='', field_pattern='', letter_count=None, unique_letters=False, transform='identity', extract_pattern=''):
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(raw.startswith(prefix), 'Response prefix mismatch: %r' % raw)
        value = raw[len(prefix):]
        if mode == 'status_and_extract_v2':
            found = list(s1d18e60290534f4e8ee0b1e639850ad0_re.finditer(field_pattern, value))
            s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(len(found) == 1 and found[0].re.groups == 1 and bool(found[0].group(1)), 'Dynamic field missing or ambiguous: %r' % raw)
            value = found[0].group(1)
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(not pattern or s1d18e60290534f4e8ee0b1e639850ad0_re.fullmatch(pattern, value) is not None, 'Dynamic field format mismatch: %r' % value)
        letters = ''.join((c for c in value if c.isascii() and c.isalpha()))
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(letter_count is None or len(letters) == letter_count, 'Dynamic field letter count mismatch')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(not unique_letters or len(set(letters)) == len(letters), 'Dynamic field letters must be distinct')
        if transform == 'letters':
            return letters
        if transform == 'regex':
            value = ''.join((''.join(m.groups(default='')) if m.re.groups else m.group() for m in s1d18e60290534f4e8ee0b1e639850ad0_re.finditer(extract_pattern, value)))
            s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(bool(value), 'Custom extraction pattern returned no value')
        return value

    @classmethod
    def init(cls):
        args = []
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        cls.clear_bindings()
        raw = tool.send_cmd('init(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [], [0]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def time_pass(cls, step_type, value):
        args = [step_type, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('time_pass(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'step_type', 'type': 'enum'}, {'name': 'value', 'type': 'integer'}], [2]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @staticmethod
    def extract_register_account_id(response):
        return s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_capture(response.rstrip('\r\n'), prefix='E000:', mode='status_and_extract_v2', field_pattern='(CID[0-9]{8})', transform='identity')

    @staticmethod
    def extract_register_account_id_1(response):
        return s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_capture(response.rstrip('\r\n'), prefix='E000:', mode='status_and_extract_v2', field_pattern=',\\s*([0-9]{6})', transform='identity')

    @classmethod
    def register_account(cls, phone, password):
        args = [phone, password]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('register_account(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'phone', 'type': 'identity'}, {'name': 'password', 'type': 'string'}], [2]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        if raw.rstrip('\r\n').startswith('E000:'):
            value = cls.extract_register_account_id(raw)
            key = ('map_register_account', tuple((str(v) for v in [args[0]])))
            values = cls._lc_bindings.setdefault(key, [])
            values.append(value)
        if raw.rstrip('\r\n').startswith('E000:'):
            value = cls.extract_register_account_id_1(raw)
            key = ('map_register_verify_code', tuple((str(v) for v in [args[0]])))
            values = cls._lc_bindings.setdefault(key, [])
            values.append(value)
        return raw

    @classmethod
    def unregister_account(cls, member_id, password):
        args = [member_id, password]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('unregister_account(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'password', 'type': 'string'}], [2]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def bind_plate_id(cls, member_id, plate_id):
        args = [member_id, plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('bind_plate_id(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'plate_id', 'type': 'identity'}], [2]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def unbind_plate_id(cls, member_id, plate_id):
        args = [member_id, plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('unbind_plate_id(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'plate_id', 'type': 'identity'}], [2]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @staticmethod
    def extract_car_entry_id(response):
        return s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_capture(response.rstrip('\r\n'), prefix='E000:', mode='status_and_extract_v2', field_pattern='(p[0-9]{16})', transform='identity')

    @classmethod
    def car_entry(cls, plate_id, gate_id):
        args = [plate_id, gate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('car_entry(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}, {'name': 'gate_id', 'type': 'enum'}], [2]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        if raw.rstrip('\r\n').startswith('E000:'):
            value = cls.extract_car_entry_id(raw)
            key = ('map_car_entry', tuple((str(v) for v in [args[0]])))
            values = cls._lc_bindings.setdefault(key, [])
            values.append(value)
        return raw

    @classmethod
    def occupy_park(cls, session_id, space_id):
        args = [session_id, space_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('occupy_park(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}, {'name': 'space_id', 'type': 'enum'}], [2]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def release_park(cls, session_id):
        args = [session_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('release_park(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}], [1]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def car_exit(cls, session_id, gate_id):
        args = [session_id, gate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('car_exit(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}, {'name': 'gate_id', 'type': 'enum'}], [2]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def change_gate(cls, gate_id, io_dir):
        args = [gate_id, io_dir]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('change_gate(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'gate_id', 'type': 'enum'}, {'name': 'io_dir', 'type': 'enum'}], [2]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_account(cls, member_id):
        args = [member_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_account(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}], [1]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_bindcar_info(cls, member_id):
        args = [member_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_bindcar_info(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}], [1]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_gate_status(cls, gate_id):
        args = [gate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_gate_status(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'gate_id', 'type': 'enum'}], [1]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_car_status(cls, plate_id, session_id, status):
        args = [plate_id, session_id, status]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_car_status(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}, {'name': 'session_id', 'type': 'string'}, {'name': 'status', 'type': 'enum'}], [3]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def add_blacklist(cls, plate_id):
        args = [plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('add_blacklist(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}], [1]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def del_blacklist(cls, plate_id):
        args = [plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('del_blacklist(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}], [1]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def recharge_account(cls, member_id, value):
        args = [member_id, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('recharge_account(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'value', 'type': 'integer'}], [2]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def transfer_account(cls, member_id1, member_id2, value):
        args = [member_id1, member_id2, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('transfer_account(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id1', 'type': 'string'}, {'name': 'member_id2', 'type': 'string'}, {'name': 'value', 'type': 'integer'}], [3]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def purchase_moncard(cls, member_id, plate_id):
        args = [member_id, plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('purchase_moncard(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'plate_id', 'type': 'identity'}], [2]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def transfer_moncard(cls, plate_id1, plate_id2, value):
        args = [plate_id1, plate_id2, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('transfer_moncard(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'plate_id1', 'type': 'identity'}, {'name': 'plate_id2', 'type': 'identity'}, {'name': 'value', 'type': 'integer'}], [3]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def pay_parkcost(cls, session_id, pay_type, pay_value):
        args = [session_id, pay_type, pay_value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('pay_parkcost(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}, {'name': 'pay_type', 'type': 'enum'}, {'name': 'pay_value', 'type': 'string'}], [3]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_account_asset(cls, member_id):
        args = [member_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_account_asset(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}], [1]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_revenue(cls, type, revenue_type, value):
        args = [type, revenue_type, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_revenue(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'type', 'type': 'enum'}, {'name': 'revenue_type', 'type': 'enum'}, {'name': 'value', 'type': 'string'}], [3]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def activate_account(cls, member_id, verify_code):
        args = [member_id, verify_code]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('activate_account(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'verify_code', 'type': 'string'}], [2]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_occupied_spaces(cls, used_num, used_park_list):
        args = [used_num, used_park_list]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_occupied_spaces(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'used_num', 'type': 'string'}, {'name': 'used_park_list', 'type': 'string'}], [2]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_park_statistics(cls, small_stats, medium_stats, large_stats):
        args = [small_stats, medium_stats, large_stats]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_park_statistics(' + s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_wire_args(args, [{'name': 'small_stats', 'type': 'string'}, {'name': 'medium_stats', 'type': 'string'}, {'name': 'large_stats', 'type': 'string'}], [3]) + ')')
        s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw
s1d18e60290534f4e8ee0b1e639850ad0_Aw = s1d18e60290534f4e8ee0b1e639850ad0_ParkingBCodexAw
s1d18e60290534f4e8ee0b1e639850ad0_init_service = s1d18e60290534f4e8ee0b1e639850ad0_Aw.init
from testtool import tool as tool
import math as s1af17c0e192c404596cbb5ac9fdcb800_math
import re as s1af17c0e192c404596cbb5ac9fdcb800_re
import unittest as s1af17c0e192c404596cbb5ac9fdcb800_unittest

class s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw:
    _ctb_direct_profile = 'direct_calls_v1'
    _lc_omitted = object()
    _lc_bindings = {}
    _lc_lifetimes = {}

    @classmethod
    def clear_bindings(cls):
        cls._lc_bindings = {}
        cls._lc_lifetimes = {}

    @classmethod
    def binding(cls, name, owners=()):
        return [value for key, values in cls._lc_bindings.items() if key[0] == name and (not owners or key[1] == tuple((str(v) for v in owners))) for n, value in enumerate(values) if cls._lc_lifetimes.get((key, n), True)]

    @staticmethod
    def _lc_require(condition, message):
        s1af17c0e192c404596cbb5ac9fdcb800_unittest.TestCase().assertTrue(condition, message)

    @staticmethod
    def _lc_atom(value, revision=1, depth=0):
        if isinstance(value, tuple):
            value = {'tuple': list(value)}
        if isinstance(value, dict) and set(value) == {'tuple'} and isinstance(value['tuple'], list) and value['tuple']:
            return '(' + ','.join((s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_atom(v, revision, depth + 1) for v in value['tuple'])) + ')'
        if isinstance(value, list):
            return '[' + ','.join((s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_atom(v, revision, depth + 1) for v in value)) + ']'
        if type(value) in (int, float):
            s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(s1af17c0e192c404596cbb5ac9fdcb800_math.isfinite(value), 'Nonfinite command argument')
            return str(value)
        forbidden = '[,(){}\\x00-\\x1f\\x7f"\\x27\\\\]|[^\\S ]' if revision == 2 and depth == 0 else '[,()\\[\\]{}\\x00-\\x1f\\x7f"\\x27\\\\]|[^\\S ]'
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(value, str) and (not s1af17c0e192c404596cbb5ac9fdcb800_re.search(forbidden, value)), 'Invalid literal argument: %r' % (value,))
        return value

    @staticmethod
    def _lc_wire_atom(value, parameter, depth=0):
        kind = parameter.get('type', 'scalar')
        container = kind in ('list', 'array', 'tuple_list', 'tuple') or parameter.get('list') is True
        if isinstance(value, tuple):
            value = {'tuple': list(value)}
        if isinstance(value, list):
            s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(container, 'structure_error: expected scalar at ' + str(parameter.get('name', 'item')))
            item = parameter.get('items') or parameter.get('item_type') or parameter.get('element_type') or dict(type='scalar')
            if isinstance(item, str):
                item = dict(type=item)
            if parameter.get('tuple_arity'):
                item = dict(type='tuple', tuple_arity=parameter['tuple_arity'])
            return '[' + ','.join((s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_atom(v, item, depth + 1) for v in value)) + ']'
        if isinstance(value, dict) and set(value) == {'tuple'}:
            s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(kind in ('tuple', 'scalar'), 'codec_capability_gap: tuple structure is not declared')
            values = value['tuple']
            s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(values, list) and bool(values) and (not parameter.get('tuple_arity') or len(values) == parameter['tuple_arity']), 'structure_error: tuple arity differs')
            return '(' + ','.join((s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_atom(v, 2, depth + 1) for v in values)) + ')'
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(not container, 'structure_error: expected container at ' + str(parameter.get('name', 'item')))
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(type(value) in (str, int, float) and (type(value) is not float or s1af17c0e192c404596cbb5ac9fdcb800_math.isfinite(value)), 'structure_error: expected finite literal')
        return s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_atom(value, 2, depth)

    @staticmethod
    def _lc_wire_args(args, parameters, arities):
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(len(args) in arities, 'structure_error: unsupported call arity')
        return ','.join((s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_atom(v, parameters[n]) for n, v in enumerate(args)))

    @staticmethod
    def _lc_capture(raw, prefix, pattern='', mode='', field_pattern='', letter_count=None, unique_letters=False, transform='identity', extract_pattern=''):
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(raw.startswith(prefix), 'Response prefix mismatch: %r' % raw)
        value = raw[len(prefix):]
        if mode == 'status_and_extract_v2':
            found = list(s1af17c0e192c404596cbb5ac9fdcb800_re.finditer(field_pattern, value))
            s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(len(found) == 1 and found[0].re.groups == 1 and bool(found[0].group(1)), 'Dynamic field missing or ambiguous: %r' % raw)
            value = found[0].group(1)
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(not pattern or s1af17c0e192c404596cbb5ac9fdcb800_re.fullmatch(pattern, value) is not None, 'Dynamic field format mismatch: %r' % value)
        letters = ''.join((c for c in value if c.isascii() and c.isalpha()))
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(letter_count is None or len(letters) == letter_count, 'Dynamic field letter count mismatch')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(not unique_letters or len(set(letters)) == len(letters), 'Dynamic field letters must be distinct')
        if transform == 'letters':
            return letters
        if transform == 'regex':
            value = ''.join((''.join(m.groups(default='')) if m.re.groups else m.group() for m in s1af17c0e192c404596cbb5ac9fdcb800_re.finditer(extract_pattern, value)))
            s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(bool(value), 'Custom extraction pattern returned no value')
        return value

    @classmethod
    def init(cls):
        args = []
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        cls.clear_bindings()
        raw = tool.send_cmd('init(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [], [0]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def time_pass(cls, step_type, value):
        args = [step_type, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('time_pass(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'step_type', 'type': 'enum'}, {'name': 'value', 'type': 'integer'}], [2]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @staticmethod
    def extract_register_account_id(response):
        return s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_capture(response.rstrip('\r\n'), prefix='E000:', mode='status_and_extract_v2', field_pattern='(CID[0-9]{8})', transform='identity')

    @staticmethod
    def extract_register_account_id_1(response):
        return s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_capture(response.rstrip('\r\n'), prefix='E000:', mode='status_and_extract_v2', field_pattern=',\\s*([0-9]{6})', transform='identity')

    @classmethod
    def register_account(cls, phone, password):
        args = [phone, password]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('register_account(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'phone', 'type': 'identity'}, {'name': 'password', 'type': 'string'}], [2]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        if raw.rstrip('\r\n').startswith('E000:'):
            value = cls.extract_register_account_id(raw)
            key = ('map_register_account', tuple((str(v) for v in [args[0]])))
            values = cls._lc_bindings.setdefault(key, [])
            values.append(value)
        if raw.rstrip('\r\n').startswith('E000:'):
            value = cls.extract_register_account_id_1(raw)
            key = ('map_register_verify_code', tuple((str(v) for v in [args[0]])))
            values = cls._lc_bindings.setdefault(key, [])
            values.append(value)
        return raw

    @classmethod
    def unregister_account(cls, member_id, password):
        args = [member_id, password]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('unregister_account(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'password', 'type': 'string'}], [2]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def bind_plate_id(cls, member_id, plate_id):
        args = [member_id, plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('bind_plate_id(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'plate_id', 'type': 'identity'}], [2]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def unbind_plate_id(cls, member_id, plate_id):
        args = [member_id, plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('unbind_plate_id(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'plate_id', 'type': 'identity'}], [2]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @staticmethod
    def extract_car_entry_id(response):
        return s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_capture(response.rstrip('\r\n'), prefix='E000:', mode='status_and_extract_v2', field_pattern='(p[0-9]{16})', transform='identity')

    @classmethod
    def car_entry(cls, plate_id, gate_id):
        args = [plate_id, gate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('car_entry(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}, {'name': 'gate_id', 'type': 'enum'}], [2]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        if raw.rstrip('\r\n').startswith('E000:'):
            value = cls.extract_car_entry_id(raw)
            key = ('map_car_entry', tuple((str(v) for v in [args[0]])))
            values = cls._lc_bindings.setdefault(key, [])
            values.append(value)
        return raw

    @classmethod
    def occupy_park(cls, session_id, space_id):
        args = [session_id, space_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('occupy_park(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}, {'name': 'space_id', 'type': 'enum'}], [2]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def release_park(cls, session_id):
        args = [session_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('release_park(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}], [1]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def car_exit(cls, session_id, gate_id):
        args = [session_id, gate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('car_exit(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}, {'name': 'gate_id', 'type': 'enum'}], [2]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def change_gate(cls, gate_id, io_dir):
        args = [gate_id, io_dir]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('change_gate(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'gate_id', 'type': 'enum'}, {'name': 'io_dir', 'type': 'enum'}], [2]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_account(cls, member_id):
        args = [member_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_account(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}], [1]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_bindcar_info(cls, member_id):
        args = [member_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_bindcar_info(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}], [1]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_gate_status(cls, gate_id):
        args = [gate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_gate_status(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'gate_id', 'type': 'enum'}], [1]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_car_status(cls, plate_id, session_id, status):
        args = [plate_id, session_id, status]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_car_status(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}, {'name': 'session_id', 'type': 'string'}, {'name': 'status', 'type': 'enum'}], [3]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def add_blacklist(cls, plate_id):
        args = [plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('add_blacklist(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}], [1]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def del_blacklist(cls, plate_id):
        args = [plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('del_blacklist(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}], [1]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def recharge_account(cls, member_id, value):
        args = [member_id, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('recharge_account(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'value', 'type': 'integer'}], [2]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def transfer_account(cls, member_id1, member_id2, value):
        args = [member_id1, member_id2, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('transfer_account(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'member_id1', 'type': 'string'}, {'name': 'member_id2', 'type': 'string'}, {'name': 'value', 'type': 'integer'}], [3]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def purchase_moncard(cls, member_id, plate_id):
        args = [member_id, plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('purchase_moncard(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'plate_id', 'type': 'identity'}], [2]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def transfer_moncard(cls, plate_id1, plate_id2, value):
        args = [plate_id1, plate_id2, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('transfer_moncard(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'plate_id1', 'type': 'identity'}, {'name': 'plate_id2', 'type': 'identity'}, {'name': 'value', 'type': 'integer'}], [3]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def pay_parkcost(cls, session_id, pay_type, pay_value):
        args = [session_id, pay_type, pay_value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('pay_parkcost(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}, {'name': 'pay_type', 'type': 'enum'}, {'name': 'pay_value', 'type': 'string'}], [3]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_account_asset(cls, member_id):
        args = [member_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_account_asset(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}], [1]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_revenue(cls, type, revenue_type, value):
        args = [type, revenue_type, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_revenue(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'type', 'type': 'enum'}, {'name': 'revenue_type', 'type': 'enum'}, {'name': 'value', 'type': 'string'}], [3]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def activate_account(cls, member_id, verify_code):
        args = [member_id, verify_code]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('activate_account(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'verify_code', 'type': 'string'}], [2]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_occupied_spaces(cls, used_num, used_park_list):
        args = [used_num, used_park_list]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_occupied_spaces(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'used_num', 'type': 'string'}, {'name': 'used_park_list', 'type': 'string'}], [2]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_park_statistics(cls, small_stats, medium_stats, large_stats):
        args = [small_stats, medium_stats, large_stats]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_park_statistics(' + s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_wire_args(args, [{'name': 'small_stats', 'type': 'string'}, {'name': 'medium_stats', 'type': 'string'}, {'name': 'large_stats', 'type': 'string'}], [3]) + ')')
        s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw
s1af17c0e192c404596cbb5ac9fdcb800_Aw = s1af17c0e192c404596cbb5ac9fdcb800_ParkingB02Aw
s1af17c0e192c404596cbb5ac9fdcb800_init_service = s1af17c0e192c404596cbb5ac9fdcb800_Aw.init
from testtool import tool as tool
import math as s67c29fe46b1e4c1c82e8c15219c42510_math
import re as s67c29fe46b1e4c1c82e8c15219c42510_re
import unittest as s67c29fe46b1e4c1c82e8c15219c42510_unittest

class s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw:
    _ctb_direct_profile = 'direct_calls_v1'
    _lc_omitted = object()
    _lc_bindings = {}
    _lc_lifetimes = {}

    @classmethod
    def clear_bindings(cls):
        cls._lc_bindings = {}
        cls._lc_lifetimes = {}

    @classmethod
    def binding(cls, name, owners=()):
        return [value for key, values in cls._lc_bindings.items() if key[0] == name and (not owners or key[1] == tuple((str(v) for v in owners))) for n, value in enumerate(values) if cls._lc_lifetimes.get((key, n), True)]

    @staticmethod
    def _lc_require(condition, message):
        s67c29fe46b1e4c1c82e8c15219c42510_unittest.TestCase().assertTrue(condition, message)

    @staticmethod
    def _lc_atom(value, revision=1, depth=0):
        if isinstance(value, tuple):
            value = {'tuple': list(value)}
        if isinstance(value, dict) and set(value) == {'tuple'} and isinstance(value['tuple'], list) and value['tuple']:
            return '(' + ','.join((s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_atom(v, revision, depth + 1) for v in value['tuple'])) + ')'
        if isinstance(value, list):
            return '[' + ','.join((s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_atom(v, revision, depth + 1) for v in value)) + ']'
        if type(value) in (int, float):
            s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(s67c29fe46b1e4c1c82e8c15219c42510_math.isfinite(value), 'Nonfinite command argument')
            return str(value)
        forbidden = '[,(){}\\x00-\\x1f\\x7f"\\x27\\\\]|[^\\S ]' if revision == 2 and depth == 0 else '[,()\\[\\]{}\\x00-\\x1f\\x7f"\\x27\\\\]|[^\\S ]'
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(value, str) and (not s67c29fe46b1e4c1c82e8c15219c42510_re.search(forbidden, value)), 'Invalid literal argument: %r' % (value,))
        return value

    @staticmethod
    def _lc_wire_atom(value, parameter, depth=0):
        kind = parameter.get('type', 'scalar')
        container = kind in ('list', 'array', 'tuple_list', 'tuple') or parameter.get('list') is True
        if isinstance(value, tuple):
            value = {'tuple': list(value)}
        if isinstance(value, list):
            s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(container, 'structure_error: expected scalar at ' + str(parameter.get('name', 'item')))
            item = parameter.get('items') or parameter.get('item_type') or parameter.get('element_type') or dict(type='scalar')
            if isinstance(item, str):
                item = dict(type=item)
            if parameter.get('tuple_arity'):
                item = dict(type='tuple', tuple_arity=parameter['tuple_arity'])
            return '[' + ','.join((s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_atom(v, item, depth + 1) for v in value)) + ']'
        if isinstance(value, dict) and set(value) == {'tuple'}:
            s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(kind in ('tuple', 'scalar'), 'codec_capability_gap: tuple structure is not declared')
            values = value['tuple']
            s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(values, list) and bool(values) and (not parameter.get('tuple_arity') or len(values) == parameter['tuple_arity']), 'structure_error: tuple arity differs')
            return '(' + ','.join((s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_atom(v, 2, depth + 1) for v in values)) + ')'
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(not container, 'structure_error: expected container at ' + str(parameter.get('name', 'item')))
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(type(value) in (str, int, float) and (type(value) is not float or s67c29fe46b1e4c1c82e8c15219c42510_math.isfinite(value)), 'structure_error: expected finite literal')
        return s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_atom(value, 2, depth)

    @staticmethod
    def _lc_wire_args(args, parameters, arities):
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(len(args) in arities, 'structure_error: unsupported call arity')
        return ','.join((s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_atom(v, parameters[n]) for n, v in enumerate(args)))

    @staticmethod
    def _lc_capture(raw, prefix, pattern='', mode='', field_pattern='', letter_count=None, unique_letters=False, transform='identity', extract_pattern=''):
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(raw.startswith(prefix), 'Response prefix mismatch: %r' % raw)
        value = raw[len(prefix):]
        if mode == 'status_and_extract_v2':
            found = list(s67c29fe46b1e4c1c82e8c15219c42510_re.finditer(field_pattern, value))
            s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(len(found) == 1 and found[0].re.groups == 1 and bool(found[0].group(1)), 'Dynamic field missing or ambiguous: %r' % raw)
            value = found[0].group(1)
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(not pattern or s67c29fe46b1e4c1c82e8c15219c42510_re.fullmatch(pattern, value) is not None, 'Dynamic field format mismatch: %r' % value)
        letters = ''.join((c for c in value if c.isascii() and c.isalpha()))
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(letter_count is None or len(letters) == letter_count, 'Dynamic field letter count mismatch')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(not unique_letters or len(set(letters)) == len(letters), 'Dynamic field letters must be distinct')
        if transform == 'letters':
            return letters
        if transform == 'regex':
            value = ''.join((''.join(m.groups(default='')) if m.re.groups else m.group() for m in s67c29fe46b1e4c1c82e8c15219c42510_re.finditer(extract_pattern, value)))
            s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(bool(value), 'Custom extraction pattern returned no value')
        return value

    @classmethod
    def init(cls):
        args = []
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        cls.clear_bindings()
        raw = tool.send_cmd('init(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [], [0]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def time_pass(cls, step_type, value):
        args = [step_type, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('time_pass(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'step_type', 'type': 'enum'}, {'name': 'value', 'type': 'integer'}], [2]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @staticmethod
    def extract_register_account_id(response):
        return s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_capture(response.rstrip('\r\n'), prefix='E000:', mode='status_and_extract_v2', field_pattern='(CID[0-9]{8})', transform='identity')

    @staticmethod
    def extract_register_account_id_1(response):
        return s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_capture(response.rstrip('\r\n'), prefix='E000:', mode='status_and_extract_v2', field_pattern=',\\s*([0-9]{6})', transform='identity')

    @classmethod
    def register_account(cls, phone, password):
        args = [phone, password]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('register_account(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'phone', 'type': 'identity'}, {'name': 'password', 'type': 'string'}], [2]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        if raw.rstrip('\r\n').startswith('E000:'):
            value = cls.extract_register_account_id(raw)
            key = ('map_register_account', tuple((str(v) for v in [args[0]])))
            values = cls._lc_bindings.setdefault(key, [])
            values.append(value)
        if raw.rstrip('\r\n').startswith('E000:'):
            value = cls.extract_register_account_id_1(raw)
            key = ('map_register_verify_code', tuple((str(v) for v in [args[0]])))
            values = cls._lc_bindings.setdefault(key, [])
            values.append(value)
        return raw

    @classmethod
    def unregister_account(cls, member_id, password):
        args = [member_id, password]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('unregister_account(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'password', 'type': 'string'}], [2]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def bind_plate_id(cls, member_id, plate_id):
        args = [member_id, plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('bind_plate_id(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'plate_id', 'type': 'identity'}], [2]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def unbind_plate_id(cls, member_id, plate_id):
        args = [member_id, plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('unbind_plate_id(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'plate_id', 'type': 'identity'}], [2]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @staticmethod
    def extract_car_entry_id(response):
        return s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_capture(response.rstrip('\r\n'), prefix='E000:', mode='status_and_extract_v2', field_pattern='(p[0-9]{16})', transform='identity')

    @classmethod
    def car_entry(cls, plate_id, gate_id):
        args = [plate_id, gate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('car_entry(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}, {'name': 'gate_id', 'type': 'enum'}], [2]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        if raw.rstrip('\r\n').startswith('E000:'):
            value = cls.extract_car_entry_id(raw)
            key = ('map_car_entry', tuple((str(v) for v in [args[0]])))
            values = cls._lc_bindings.setdefault(key, [])
            values.append(value)
        return raw

    @classmethod
    def occupy_park(cls, session_id, space_id):
        args = [session_id, space_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('occupy_park(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}, {'name': 'space_id', 'type': 'enum'}], [2]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def release_park(cls, session_id):
        args = [session_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('release_park(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}], [1]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def car_exit(cls, session_id, gate_id):
        args = [session_id, gate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('car_exit(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}, {'name': 'gate_id', 'type': 'enum'}], [2]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def change_gate(cls, gate_id, io_dir):
        args = [gate_id, io_dir]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('change_gate(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'gate_id', 'type': 'enum'}, {'name': 'io_dir', 'type': 'enum'}], [2]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_account(cls, member_id):
        args = [member_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_account(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}], [1]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_bindcar_info(cls, member_id):
        args = [member_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_bindcar_info(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}], [1]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_gate_status(cls, gate_id):
        args = [gate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_gate_status(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'gate_id', 'type': 'enum'}], [1]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_car_status(cls, plate_id, session_id, status):
        args = [plate_id, session_id, status]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_car_status(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}, {'name': 'session_id', 'type': 'string'}, {'name': 'status', 'type': 'enum'}], [3]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def add_blacklist(cls, plate_id):
        args = [plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('add_blacklist(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}], [1]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def del_blacklist(cls, plate_id):
        args = [plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('del_blacklist(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}], [1]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def recharge_account(cls, member_id, value):
        args = [member_id, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('recharge_account(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'value', 'type': 'integer'}], [2]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def transfer_account(cls, member_id1, member_id2, value):
        args = [member_id1, member_id2, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('transfer_account(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id1', 'type': 'string'}, {'name': 'member_id2', 'type': 'string'}, {'name': 'value', 'type': 'integer'}], [3]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def purchase_moncard(cls, member_id, plate_id):
        args = [member_id, plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('purchase_moncard(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'plate_id', 'type': 'identity'}], [2]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def transfer_moncard(cls, plate_id1, plate_id2, value):
        args = [plate_id1, plate_id2, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('transfer_moncard(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'plate_id1', 'type': 'identity'}, {'name': 'plate_id2', 'type': 'identity'}, {'name': 'value', 'type': 'integer'}], [3]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def pay_parkcost(cls, session_id, pay_type, pay_value):
        args = [session_id, pay_type, pay_value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('pay_parkcost(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}, {'name': 'pay_type', 'type': 'enum'}, {'name': 'pay_value', 'type': 'string'}], [3]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_account_asset(cls, member_id):
        args = [member_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_account_asset(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}], [1]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_revenue(cls, type, revenue_type, value):
        args = [type, revenue_type, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_revenue(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'type', 'type': 'enum'}, {'name': 'revenue_type', 'type': 'enum'}, {'name': 'value', 'type': 'string'}], [3]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def activate_account(cls, member_id, verify_code):
        args = [member_id, verify_code]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('activate_account(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'verify_code', 'type': 'string'}], [2]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_occupied_spaces(cls, used_num, used_park_list):
        args = [used_num, used_park_list]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_occupied_spaces(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'used_num', 'type': 'string'}, {'name': 'used_park_list', 'type': 'string'}], [2]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_park_statistics(cls, small_stats, medium_stats, large_stats):
        args = [small_stats, medium_stats, large_stats]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_park_statistics(' + s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_wire_args(args, [{'name': 'small_stats', 'type': 'string'}, {'name': 'medium_stats', 'type': 'string'}, {'name': 'large_stats', 'type': 'string'}], [3]) + ')')
        s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw
s67c29fe46b1e4c1c82e8c15219c42510_Aw = s67c29fe46b1e4c1c82e8c15219c42510_ParkingBCodexAw
s67c29fe46b1e4c1c82e8c15219c42510_init_service = s67c29fe46b1e4c1c82e8c15219c42510_Aw.init
from testtool import tool as tool
import math as s3bea283849af430dadd7cd2d024aa658_math
import re as s3bea283849af430dadd7cd2d024aa658_re
import unittest as s3bea283849af430dadd7cd2d024aa658_unittest

class s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw:
    _ctb_direct_profile = 'direct_calls_v1'
    _lc_omitted = object()
    _lc_bindings = {}
    _lc_lifetimes = {}

    @classmethod
    def clear_bindings(cls):
        cls._lc_bindings = {}
        cls._lc_lifetimes = {}

    @classmethod
    def binding(cls, name, owners=()):
        return [value for key, values in cls._lc_bindings.items() if key[0] == name and (not owners or key[1] == tuple((str(v) for v in owners))) for n, value in enumerate(values) if cls._lc_lifetimes.get((key, n), True)]

    @staticmethod
    def _lc_require(condition, message):
        s3bea283849af430dadd7cd2d024aa658_unittest.TestCase().assertTrue(condition, message)

    @staticmethod
    def _lc_atom(value, revision=1, depth=0):
        if isinstance(value, tuple):
            value = {'tuple': list(value)}
        if isinstance(value, dict) and set(value) == {'tuple'} and isinstance(value['tuple'], list) and value['tuple']:
            return '(' + ','.join((s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_atom(v, revision, depth + 1) for v in value['tuple'])) + ')'
        if isinstance(value, list):
            return '[' + ','.join((s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_atom(v, revision, depth + 1) for v in value)) + ']'
        if type(value) in (int, float):
            s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(s3bea283849af430dadd7cd2d024aa658_math.isfinite(value), 'Nonfinite command argument')
            return str(value)
        forbidden = '[,(){}\\x00-\\x1f\\x7f"\\x27\\\\]|[^\\S ]' if revision == 2 and depth == 0 else '[,()\\[\\]{}\\x00-\\x1f\\x7f"\\x27\\\\]|[^\\S ]'
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(value, str) and (not s3bea283849af430dadd7cd2d024aa658_re.search(forbidden, value)), 'Invalid literal argument: %r' % (value,))
        return value

    @staticmethod
    def _lc_wire_atom(value, parameter, depth=0):
        kind = parameter.get('type', 'scalar')
        container = kind in ('list', 'array', 'tuple_list', 'tuple') or parameter.get('list') is True
        if isinstance(value, tuple):
            value = {'tuple': list(value)}
        if isinstance(value, list):
            s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(container, 'structure_error: expected scalar at ' + str(parameter.get('name', 'item')))
            item = parameter.get('items') or parameter.get('item_type') or parameter.get('element_type') or dict(type='scalar')
            if isinstance(item, str):
                item = dict(type=item)
            if parameter.get('tuple_arity'):
                item = dict(type='tuple', tuple_arity=parameter['tuple_arity'])
            return '[' + ','.join((s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_atom(v, item, depth + 1) for v in value)) + ']'
        if isinstance(value, dict) and set(value) == {'tuple'}:
            s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(kind in ('tuple', 'scalar'), 'codec_capability_gap: tuple structure is not declared')
            values = value['tuple']
            s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(values, list) and bool(values) and (not parameter.get('tuple_arity') or len(values) == parameter['tuple_arity']), 'structure_error: tuple arity differs')
            return '(' + ','.join((s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_atom(v, 2, depth + 1) for v in values)) + ')'
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(not container, 'structure_error: expected container at ' + str(parameter.get('name', 'item')))
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(type(value) in (str, int, float) and (type(value) is not float or s3bea283849af430dadd7cd2d024aa658_math.isfinite(value)), 'structure_error: expected finite literal')
        return s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_atom(value, 2, depth)

    @staticmethod
    def _lc_wire_args(args, parameters, arities):
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(len(args) in arities, 'structure_error: unsupported call arity')
        return ','.join((s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_atom(v, parameters[n]) for n, v in enumerate(args)))

    @staticmethod
    def _lc_capture(raw, prefix, pattern='', mode='', field_pattern='', letter_count=None, unique_letters=False, transform='identity', extract_pattern=''):
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(raw.startswith(prefix), 'Response prefix mismatch: %r' % raw)
        value = raw[len(prefix):]
        if mode == 'status_and_extract_v2':
            found = list(s3bea283849af430dadd7cd2d024aa658_re.finditer(field_pattern, value))
            s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(len(found) == 1 and found[0].re.groups == 1 and bool(found[0].group(1)), 'Dynamic field missing or ambiguous: %r' % raw)
            value = found[0].group(1)
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(not pattern or s3bea283849af430dadd7cd2d024aa658_re.fullmatch(pattern, value) is not None, 'Dynamic field format mismatch: %r' % value)
        letters = ''.join((c for c in value if c.isascii() and c.isalpha()))
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(letter_count is None or len(letters) == letter_count, 'Dynamic field letter count mismatch')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(not unique_letters or len(set(letters)) == len(letters), 'Dynamic field letters must be distinct')
        if transform == 'letters':
            return letters
        if transform == 'regex':
            value = ''.join((''.join(m.groups(default='')) if m.re.groups else m.group() for m in s3bea283849af430dadd7cd2d024aa658_re.finditer(extract_pattern, value)))
            s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(bool(value), 'Custom extraction pattern returned no value')
        return value

    @classmethod
    def init(cls):
        args = []
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        cls.clear_bindings()
        raw = tool.send_cmd('init(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [], [0]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def time_pass(cls, step_type, value):
        args = [step_type, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('time_pass(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'step_type', 'type': 'enum'}, {'name': 'value', 'type': 'integer'}], [2]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @staticmethod
    def extract_register_account_id(response):
        return s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_capture(response.rstrip('\r\n'), prefix='E000:', mode='status_and_extract_v2', field_pattern='(CID[0-9]{8})', transform='identity')

    @staticmethod
    def extract_register_account_id_1(response):
        return s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_capture(response.rstrip('\r\n'), prefix='E000:', mode='status_and_extract_v2', field_pattern=',\\s*([0-9]{6})', transform='identity')

    @classmethod
    def register_account(cls, phone, password):
        args = [phone, password]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('register_account(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'phone', 'type': 'identity'}, {'name': 'password', 'type': 'string'}], [2]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        if raw.rstrip('\r\n').startswith('E000:'):
            value = cls.extract_register_account_id(raw)
            key = ('map_register_account', tuple((str(v) for v in [args[0]])))
            values = cls._lc_bindings.setdefault(key, [])
            values.append(value)
        if raw.rstrip('\r\n').startswith('E000:'):
            value = cls.extract_register_account_id_1(raw)
            key = ('map_register_verify_code', tuple((str(v) for v in [args[0]])))
            values = cls._lc_bindings.setdefault(key, [])
            values.append(value)
        return raw

    @classmethod
    def unregister_account(cls, member_id, password):
        args = [member_id, password]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('unregister_account(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'password', 'type': 'string'}], [2]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def bind_plate_id(cls, member_id, plate_id):
        args = [member_id, plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('bind_plate_id(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'plate_id', 'type': 'identity'}], [2]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def unbind_plate_id(cls, member_id, plate_id):
        args = [member_id, plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('unbind_plate_id(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'plate_id', 'type': 'identity'}], [2]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @staticmethod
    def extract_car_entry_id(response):
        return s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_capture(response.rstrip('\r\n'), prefix='E000:', mode='status_and_extract_v2', field_pattern='(p[0-9]{16})', transform='identity')

    @classmethod
    def car_entry(cls, plate_id, gate_id):
        args = [plate_id, gate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('car_entry(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}, {'name': 'gate_id', 'type': 'enum'}], [2]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        if raw.rstrip('\r\n').startswith('E000:'):
            value = cls.extract_car_entry_id(raw)
            key = ('map_car_entry', tuple((str(v) for v in [args[0]])))
            values = cls._lc_bindings.setdefault(key, [])
            values.append(value)
        return raw

    @classmethod
    def occupy_park(cls, session_id, space_id):
        args = [session_id, space_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('occupy_park(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}, {'name': 'space_id', 'type': 'enum'}], [2]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def release_park(cls, session_id):
        args = [session_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('release_park(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}], [1]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def car_exit(cls, session_id, gate_id):
        args = [session_id, gate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('car_exit(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}, {'name': 'gate_id', 'type': 'enum'}], [2]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def change_gate(cls, gate_id, io_dir):
        args = [gate_id, io_dir]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('change_gate(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'gate_id', 'type': 'enum'}, {'name': 'io_dir', 'type': 'enum'}], [2]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_account(cls, member_id):
        args = [member_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_account(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}], [1]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_bindcar_info(cls, member_id):
        args = [member_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_bindcar_info(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}], [1]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_gate_status(cls, gate_id):
        args = [gate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_gate_status(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'gate_id', 'type': 'enum'}], [1]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_car_status(cls, plate_id, session_id, status):
        args = [plate_id, session_id, status]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_car_status(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}, {'name': 'session_id', 'type': 'string'}, {'name': 'status', 'type': 'enum'}], [3]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def add_blacklist(cls, plate_id):
        args = [plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('add_blacklist(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}], [1]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def del_blacklist(cls, plate_id):
        args = [plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('del_blacklist(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'plate_id', 'type': 'identity'}], [1]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def recharge_account(cls, member_id, value):
        args = [member_id, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('recharge_account(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'value', 'type': 'integer'}], [2]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def transfer_account(cls, member_id1, member_id2, value):
        args = [member_id1, member_id2, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('transfer_account(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id1', 'type': 'string'}, {'name': 'member_id2', 'type': 'string'}, {'name': 'value', 'type': 'integer'}], [3]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def purchase_moncard(cls, member_id, plate_id):
        args = [member_id, plate_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('purchase_moncard(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'plate_id', 'type': 'identity'}], [2]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def transfer_moncard(cls, plate_id1, plate_id2, value):
        args = [plate_id1, plate_id2, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('transfer_moncard(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'plate_id1', 'type': 'identity'}, {'name': 'plate_id2', 'type': 'identity'}, {'name': 'value', 'type': 'integer'}], [3]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def pay_parkcost(cls, session_id, pay_type, pay_value):
        args = [session_id, pay_type, pay_value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('pay_parkcost(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'session_id', 'type': 'string'}, {'name': 'pay_type', 'type': 'enum'}, {'name': 'pay_value', 'type': 'string'}], [3]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def query_account_asset(cls, member_id):
        args = [member_id]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('query_account_asset(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}], [1]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_revenue(cls, type, revenue_type, value):
        args = [type, revenue_type, value]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_revenue(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'type', 'type': 'enum'}, {'name': 'revenue_type', 'type': 'enum'}, {'name': 'value', 'type': 'string'}], [3]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def activate_account(cls, member_id, verify_code):
        args = [member_id, verify_code]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('activate_account(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'member_id', 'type': 'string'}, {'name': 'verify_code', 'type': 'string'}], [2]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_occupied_spaces(cls, used_num, used_park_list):
        args = [used_num, used_park_list]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_occupied_spaces(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'used_num', 'type': 'string'}, {'name': 'used_park_list', 'type': 'string'}], [2]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw

    @classmethod
    def check_park_statistics(cls, small_stats, medium_stats, large_stats):
        args = [small_stats, medium_stats, large_stats]
        while args and args[-1] is cls._lc_omitted:
            args.pop()
        raw = tool.send_cmd('check_park_statistics(' + s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_wire_args(args, [{'name': 'small_stats', 'type': 'string'}, {'name': 'medium_stats', 'type': 'string'}, {'name': 'large_stats', 'type': 'string'}], [3]) + ')')
        s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw._lc_require(isinstance(raw, str) and bool(raw.strip()), 'Reference returned no text')
        return raw
s3bea283849af430dadd7cd2d024aa658_Aw = s3bea283849af430dadd7cd2d024aa658_ParkingBCodexAw
s3bea283849af430dadd7cd2d024aa658_init_service = s3bea283849af430dadd7cd2d024aa658_Aw.init
from testtool import tool as tool
import re as s8313b1c4b0bf417cad537a9652de8480_re

def s8313b1c4b0bf417cad537a9652de8480_cjl_init_service():
    return tool.send_cmd('init()')

def s8313b1c4b0bf417cad537a9652de8480_cjl_run_turns(times=1):
    for i in range(times):
        tool.send_cmd('init()')
s8313b1c4b0bf417cad537a9652de8480_rS = 'E000:Success'
s8313b1c4b0bf417cad537a9652de8480_rF = 'E001:Fail'
s8313b1c4b0bf417cad537a9652de8480_rL = 'E002:Locked'
s8313b1c4b0bf417cad537a9652de8480_SP = {'E001:Fail': 'rF', 'E000:Success': 'rS', 'E002:Locked': 'rL'}

class s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil:
    """
    通用的命令下发AW，提供normal、ret_id两种模式，供cjl_Aw方法使用
    """
    JUDGEMENT_FLAG = True
    CALCBASE = 10
    TIMEFORMAT = '%Y-%m-%d %H:%M:%S'
    RECORD_FAIL_FLAG = True
    TC_Start = []
    TC_End = []
    CASE_ID = 0

    @staticmethod
    def next_testcase(name):
        s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.CASE_ID += 1
        s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.add_context(f'    def test_{name}(self):', '        cjl_init_service()')

    @staticmethod
    def add_context(*context):
        for s in context:
            if not s.endswith('\n'):
                s += '\n'
            s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.TC_Start.append(s)

    @staticmethod
    def _add_aw_context(cmd, ret, aw_name='', *args):
        if not s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.RECORD_FAIL_FLAG and ret == s8313b1c4b0bf417cad537a9652de8480_rF:
            return
        if ret in s8313b1c4b0bf417cad537a9652de8480_SP:
            ret = s8313b1c4b0bf417cad537a9652de8480_SP[ret]
        else:
            ret = f"'{ret}'"
        cmd = aw_name if aw_name else cmd

        def fmt_arg(x):
            if isinstance(x, (int, float)):
                return str(x)
            return f"'{x}'"
        args_list = [fmt_arg(x) for x in args]
        args_str = f"{','.join(args_list)}, " if args_list else ''
        context = f'        aw.{cmd}({args_str}expects={ret})'
        s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.add_context(context)

    @staticmethod
    def send_cmd(cmd, *args, **kwargs):
        full_cmd = f"{cmd}({','.join([str(x) for x in args])})"
        ret = tool.send_cmd(full_cmd).replace('\n', '')
        return ret

    @staticmethod
    def send_cmd_normal(cmd: str, *args, aw_name='', **expects):
        """
        适合入参范围明确、返回值固定的函数，全等比较
        """
        ret = s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd(cmd, *args)
        if not s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG:
            s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil._add_aw_context(cmd, ret, aw_name if aw_name else 'cjl_' + cmd, *args)
        else:
            if 'expects' not in expects or expects['expects'] == '':
                raise ValueError(f'JUDGEMENT_FLAG=True but expects not provided for: {cmd}({args})')
            expect_value = expects['expects']
            assert ret == expect_value, f'cmd={cmd}({args}), expected={expect_value!r}, actual={ret!r}'
        return ret

    @staticmethod
    def send_cmd_ret_id(cmd: str, *args, aw_name='', **expects):
        """
        适合返回值带动态ID，ID值不做全等校验、只比前5字符
        """
        ret = s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd(cmd, *args)
        if not s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG:
            s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil._add_aw_context(cmd, ret, aw_name if aw_name else 'cjl_' + cmd, *args)
        else:
            if 'expects' not in expects or expects['expects'] == '':
                raise ValueError(f'JUDGEMENT_FLAG=True but expects not provided for: {cmd}({args})')
            expect_value = expects['expects']
            if expect_value in s8313b1c4b0bf417cad537a9652de8480_SP:
                assert ret == expect_value, f'cmd={cmd}({args}), expected={expect_value!r}, actual={ret!r}'
            else:
                assert ret[:5] == expect_value[:5], f'cmd={cmd}({args}), expected_prefix={expect_value[:5]!r}, actual_prefix={ret[:5]!r}, full_actual={ret!r}'
        return ret

class s8313b1c4b0bf417cad537a9652de8480_cjl_Aw:
    """智慧园区停车场系统(B版本) AW封装

    在A版本基础上新增：
      - 黑名单：add_blacklist / del_blacklist
      - 账户充值：recharge_account
      - 余额转让：transfer_account
      - 月卡：purchase_moncard / transfer_moncard
      - 账单结算：pay_parkcost
      - 查询资产：query_account_asset
      - 检查接口：check_occupied_spaces / check_park_statistics / check_revenue
    变更：
      - occupy_park 新增 space_id 参数
    """
    map_member = {}
    map_code = {}
    map_session = {}

    @staticmethod
    def _extract_field(text, prefix, suffix=''):
        """从text中提取prefix和suffix之间的内容"""
        start = text.find(prefix)
        if start == -1:
            return None
        start += len(prefix)
        if suffix:
            end = text.find(suffix, start)
            if end == -1:
                return text[start:]
            return text[start:end]
        return text[start:]

    @staticmethod
    def _bind(table, recorded, actual, what):
        """录制值到实际值的映射：已出现的录制值必须对应同一实际值，新录制值不能对应已用过的实际值"""
        if recorded in table:
            assert table[recorded] == actual, f'{what}: recorded={recorded!r} mapped={table[recorded]!r}, actual={actual!r}'
        else:
            assert actual not in table.values(), f'{what}: recorded={recorded!r} is new but actual={actual!r} already used'
            table[recorded] = actual

    @staticmethod
    def init(expects=s8313b1c4b0bf417cad537a9652de8480_rS):
        maps = [i for i in s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.__dict__ if i[0:4] == 'map_']
        for i in maps:
            setattr(s8313b1c4b0bf417cad537a9652de8480_cjl_Aw, i, {})
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('init', expects=expects)

    @staticmethod
    def cjl_time_pass(step_type, value, expects=''):
        args = [step_type, value]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('time_pass', *args, expects=expects)

    @staticmethod
    def cjl_register_account(phone, password, expects=''):
        """返回 E000:CIDxxxx,6位验证码，拆分并映射 member_id 和 code"""
        args = [phone, password]
        ret = s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_ret_id('register_account', *args, expects=expects)
        m = s8313b1c4b0bf417cad537a9652de8480_re.match('E000:(CID\\d{8}),(\\d{6})', ret)
        if not m:
            return ret
        cid, code = (m.group(1), m.group(2))
        if s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG and expects.startswith('E000:'):
            em = s8313b1c4b0bf417cad537a9652de8480_re.match('E000:(CID\\d{8}),(\\d{6})', expects)
            if em:
                s8313b1c4b0bf417cad537a9652de8480_cjl_Aw._bind(s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member, em.group(1), cid, 'register_account member_id')
                s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_code[em.group(1)] = (em.group(2), code)
        return (cid, code)

    @staticmethod
    def cjl_activate_account(member_id, verify_code, expects=''):
        """验证码按录制的 member_id 映射：传入值等于该账户录制时的验证码才替换为实际验证码"""
        if s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG:
            recorded = s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_code.get(member_id)
            if recorded and verify_code == recorded[0]:
                verify_code = recorded[1]
            if member_id in s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member:
                member_id = s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member[member_id]
        args = [member_id, verify_code]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('activate_account', *args, expects=expects)

    @staticmethod
    def cjl_unregister_account(member_id, password, expects=''):
        if s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG and member_id in s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member:
            member_id = s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member[member_id]
        args = [member_id, password]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('unregister_account', *args, expects=expects)

    @staticmethod
    def cjl_query_account(member_id, expects=''):
        if s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG and member_id in s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member:
            member_id = s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member[member_id]
        args = [member_id]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('query_account', *args, expects=expects)

    @staticmethod
    def cjl_bind_plate_id(member_id, plate_id, expects=''):
        if s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG and member_id in s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member:
            member_id = s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member[member_id]
        args = [member_id, plate_id]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('bind_plate_id', *args, expects=expects)

    @staticmethod
    def cjl_unbind_plate_id(member_id, plate_id, expects=''):
        if s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG and member_id in s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member:
            member_id = s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member[member_id]
        args = [member_id, plate_id]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('unbind_plate_id', *args, expects=expects)

    @staticmethod
    def cjl_query_bindcar_info(member_id, expects=''):
        if s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG and member_id in s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member:
            member_id = s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member[member_id]
        args = [member_id]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('query_bindcar_info', *args, expects=expects)

    @staticmethod
    def cjl_car_entry(plate_id, gate_id, expects=''):
        """返回 E000:session_id,account_id，拆分并映射 session_id"""
        args = [plate_id, gate_id]
        ret = s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_ret_id('car_entry', *args, expects=expects)
        m = s8313b1c4b0bf417cad537a9652de8480_re.match('E000:(p\\d{16}),(CID\\d{8})', ret)
        if not m:
            return ret
        session_id, acc_id = (m.group(1), m.group(2))
        if s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG and expects.startswith('E000:'):
            em = s8313b1c4b0bf417cad537a9652de8480_re.match('E000:(p\\d{16}),(CID\\d{8})', expects)
            if em:
                s8313b1c4b0bf417cad537a9652de8480_cjl_Aw._bind(s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_session, em.group(1), session_id, 'car_entry session_id')
                s8313b1c4b0bf417cad537a9652de8480_cjl_Aw._bind(s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member, em.group(2), acc_id, 'car_entry account_id')
        return (session_id, acc_id)

    @staticmethod
    def cjl_occupy_park(session_id, space_id=None, expects=''):
        """B版本新增 space_id 参数；A版本不传 space_id"""
        if s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG and session_id in s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_session:
            session_id = s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_session[session_id]
        args = [session_id] if space_id is None else [session_id, space_id]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('occupy_park', *args, expects=expects)

    @staticmethod
    def cjl_release_park(session_id, expects=''):
        """B版本：返回 E000:车位号（如E000:S010），车位号确定，全等比较"""
        if s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG and session_id in s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_session:
            session_id = s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_session[session_id]
        args = [session_id]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('release_park', *args, expects=expects)

    @staticmethod
    def cjl_car_exit(session_id, gate_id, expects=''):
        if s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG and session_id in s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_session:
            session_id = s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_session[session_id]
        args = [session_id, gate_id]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('car_exit', *args, expects=expects)

    @staticmethod
    def cjl_check_car_status(plate_id, session_id, status, expects=''):
        if s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG and session_id in s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_session:
            session_id = s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_session[session_id]
        args = [plate_id, session_id, status]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('check_car_status', *args, expects=expects)

    @staticmethod
    def cjl_change_gate(gate_id, io_dir, expects=''):
        args = [gate_id, io_dir]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('change_gate', *args, expects=expects)

    @staticmethod
    def cjl_query_gate_status(gate_id, expects=''):
        args = [gate_id]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('query_gate_status', *args, expects=expects)

    @staticmethod
    def cjl_add_blacklist(plate_id, expects=''):
        args = [plate_id]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('add_blacklist', *args, expects=expects)

    @staticmethod
    def cjl_del_blacklist(plate_id, expects=''):
        args = [plate_id]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('del_blacklist', *args, expects=expects)

    @staticmethod
    def cjl_recharge_account(member_id, value, expects=''):
        if s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG and member_id in s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member:
            member_id = s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member[member_id]
        args = [member_id, value]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('recharge_account', *args, expects=expects)

    @staticmethod
    def cjl_transfer_account(member_id1, member_id2, value, expects=''):
        if s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG and member_id1 in s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member:
            member_id1 = s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member[member_id1]
        if s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG and member_id2 in s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member:
            member_id2 = s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member[member_id2]
        args = [member_id1, member_id2, value]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('transfer_account', *args, expects=expects)

    @staticmethod
    def cjl_purchase_moncard(member_id, plate_id, expects=''):
        if s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG and member_id in s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member:
            member_id = s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member[member_id]
        args = [member_id, plate_id]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('purchase_moncard', *args, expects=expects)

    @staticmethod
    def cjl_transfer_moncard(plate_id1, plate_id2, value, expects=''):
        args = [plate_id1, plate_id2, value]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('transfer_moncard', *args, expects=expects)

    @staticmethod
    def cjl_pay_parkcost(session_id, pay_type, pay_value, expects=''):
        if s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG and session_id in s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_session:
            session_id = s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_session[session_id]
        args = [session_id, pay_type, pay_value]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('pay_parkcost', *args, expects=expects)

    @staticmethod
    def cjl_query_account_asset(member_id, expects=''):
        if s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.JUDGEMENT_FLAG and member_id in s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member:
            member_id = s8313b1c4b0bf417cad537a9652de8480_cjl_Aw.map_member[member_id]
        args = [member_id]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('query_account_asset', *args, expects=expects)

    @staticmethod
    def cjl_check_occupied_spaces(used_num, used_park_list, expects=''):
        args = [used_num, used_park_list]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('check_occupied_spaces', *args, expects=expects)

    @staticmethod
    def cjl_check_park_statistics(small_stats, medium_stats, large_stats, expects=''):
        args = [small_stats, medium_stats, large_stats]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('check_park_statistics', *args, expects=expects)

    @staticmethod
    def cjl_check_revenue(type_, revenue_type, value, expects=''):
        args = [type_, revenue_type, value]
        return s8313b1c4b0bf417cad537a9652de8480_cjl_CommonUtil.send_cmd_normal('check_revenue', *args, expects=expects)
